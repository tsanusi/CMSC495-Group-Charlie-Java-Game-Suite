package Snake;// Snake.Snake Game
// CMSC 495
// Professor: Mark Munoz
// Programmers: Oyewole Sanusi



import javax.swing.*;
import java.awt.*;

public class Snake extends JFrame {

    public Snake() {

        initUI();
    }

    private void initUI() {

        add(new Board());

        setResizable(false);
        pack();

        setTitle("Snake");
        setLocationRelativeTo(null);
    }


    public static void main(String[] args) {

        EventQueue.invokeLater(() -> {
            JFrame ex = new Snake();
            ex.setVisible(true);
        });
    }
}
