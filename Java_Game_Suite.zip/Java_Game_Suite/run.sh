#!/bin/bash

javac Main.java
java Main

