Java Game Suite is a simple GUI-based application that allows users to play several single-player computer games: a maze, snakes, Sudoku, word search, and a slider puzzle.

To play have the latest version of Java installed.
Type the following on the command line:
 ./run.sh


